import React from 'react'
import './RecentlyAccesedClasses.css'
const RecentlyAccesedClasses = ({subject}) => {
  return (
      <div className='RecentlyAccesedClasses'>
          <span>{subject }</span>
    </div>
  )
}

export default RecentlyAccesedClasses